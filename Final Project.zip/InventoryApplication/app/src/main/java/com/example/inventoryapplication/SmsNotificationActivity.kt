package com.example.inventoryapplication

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Switch
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class SmsNotificationActivity : ComponentActivity() {

    private lateinit var switchSms: Switch
    private lateinit var txtSmsStatus: TextView

    private val prefs by lazy { getSharedPreferences("sms_prefs", MODE_PRIVATE) }

    private fun hasSmsPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED

    private val requestSmsPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                prefs.edit().putBoolean("sms_enabled", true).apply()
                updateUiState()
                Toast.makeText(this, "SMS permission granted — alerts enabled.", Toast.LENGTH_SHORT).show()
            } else {
                prefs.edit().putBoolean("sms_enabled", false).apply()
                updateUiState()
                AlertDialog.Builder(this)
                    .setTitle("Permission required")
                    .setMessage("To send low-inventory SMS alerts, enable the SMS permission.")
                    .setPositiveButton("Open Permissions") { _, _ -> openAppPermissionSettings() }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_notifications)

        switchSms = findViewById(R.id.switchSms)
        txtSmsStatus = findViewById(R.id.txtSmsStatus)

        updateUiState()

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            Toast.makeText(this, "Preferences saved.", Toast.LENGTH_SHORT).show()

            // Navigate back to inventory screen
            val intent = Intent(this, InventoryActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }

        switchSms.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (hasSmsPermission()) {
                    prefs.edit().putBoolean("sms_enabled", true).apply()
                    updateUiState()
                    Toast.makeText(this, "SMS alerts enabled.", Toast.LENGTH_SHORT).show()
                } else {
                    requestSmsPermission.launch(Manifest.permission.SEND_SMS)
                }
            } else {
                prefs.edit().putBoolean("sms_enabled", false).apply()
                updateUiState()
                Toast.makeText(this, "SMS alerts disabled.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!hasSmsPermission()) {
            prefs.edit().putBoolean("sms_enabled", false).apply()
        }
        updateUiState()
    }

    private fun updateUiState() {
        val enabled = prefs.getBoolean("sms_enabled", false)
        val perm = hasSmsPermission()
        switchSms.isChecked = enabled && perm
        txtSmsStatus.text = when {
            perm && enabled -> "Status: Enabled (permission granted)"
            perm && !enabled -> "Status: Disabled (permission granted)"
            else -> "Status: Disabled (permission denied)"
        }
    }

    private fun openAppPermissionSettings() {
        startActivity(
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
