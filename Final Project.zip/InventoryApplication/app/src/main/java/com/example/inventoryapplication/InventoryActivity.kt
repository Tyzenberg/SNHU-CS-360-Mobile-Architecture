
package com.example.inventoryapplication

import android.Manifest
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.view.ViewGroup
import android.widget.*

import android.app.AlertDialog
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat

class InventoryActivity : ComponentActivity() {

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)
        refreshRows()
        // Add Item
        findViewById<ImageButton>(R.id.btnAddItem)?.setOnClickListener {
            startActivity(Intent(this, AddItemActivity::class.java))
        }

        // Profile button - current place for sms screen
        findViewById<ImageButton>(R.id.btnProfile)?.setOnClickListener {
            startActivity(Intent(this, SmsNotificationActivity::class.java))
        }


    }

    override fun onResume() {
        super.onResume()
        refreshRows()   // re-query DB every time you return to this screen
    }

    private fun refreshRows() {
        val container = findViewById<LinearLayout>(R.id.rowsContainer)
        container.removeAllViews()
        val db = DatabaseHelper(this)
        val c = db.allItems()
        c.use {
            while (it.moveToNext()) {
                val id = it.getLong(0)
                val name = it.getString(1)
                val qty = it.getInt(2)

                val row = LayoutInflater.from(this).inflate(R.layout.inventory_row, container, false)
                row.findViewById<TextView>(R.id.rowName).text = name
                row.findViewById<TextView>(R.id.rowQty).text = "Qty: $qty"

                // give each row side/vertical spacing
                val rowLp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(dp(12), dp(6), dp(12), dp(6))
                }
                row.layoutParams = rowLp

// optional: extra padding so the border doesn't hug contents
                row.setPadding(dp(12), dp(12), dp(12), dp(12))

                // Border color by quantity
                when {
                    qty <= 1 -> row.setBackgroundResource(R.drawable.border_out)
                    qty < 5 -> row.setBackgroundResource(R.drawable.border_low)
                    else -> row.setBackgroundResource(R.drawable.border_excess)
                }

                row.setOnClickListener { showEditDialog(id, name, qty) }
                row.findViewById<ImageButton>(R.id.btnDeleteItem).setOnClickListener {
                    AlertDialog.Builder(this)                // <- android.app.AlertDialog
                        .setTitle("Delete item?")
                        .setMessage("Are you sure you want to delete \"$name\" from inventory?")
                        .setPositiveButton("Delete") { _, _ ->
                            DatabaseHelper(this).deleteItem(id)
                            refreshRows()
                            Toast.makeText(this, "Deleted \"$name\"", Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }

                container.addView(row)
            }
        }
    }

    private fun showEditDialog(id: Long, currentName: String, currentQty: Int) {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,16,32,0) }
        val editName = EditText(this).apply { setText(currentName) }
        val editQty = EditText(this).apply { setText(currentQty.toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val editLoc = EditText(this).apply { hint = "Location (optional)" }
        val editDesc = EditText(this).apply { hint = "Description (optional)" }
        layout.addView(editName); layout.addView(editQty); layout.addView(editLoc); layout.addView(editDesc)

        AlertDialog.Builder(this)
            .setTitle("Update/Delete Item")
            .setView(layout)
            .setPositiveButton("Update") { _, _ ->
                val name = editName.text.toString().trim()
                val qty = editQty.text.toString().toIntOrNull() ?: 0
                val loc = editLoc.text.toString().trim().ifEmpty { null }
                val desc = editDesc.text.toString().trim().ifEmpty { null }
                DatabaseHelper(this).updateItem(id, name, qty, loc, description = desc)
                if (qty < 5) maybeSendSms("$name low: $qty")
                refreshRows()
            }
            .setNeutralButton("Delete") { _, _ ->
                DatabaseHelper(this).deleteItem(id)
                refreshRows()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun hasSmsPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    private fun isSmsAlertsEnabled(): Boolean =
        getSharedPreferences("sms_prefs", MODE_PRIVATE)
            .getBoolean("sms_enabled", false)

    private fun maybeSendSms(text: String) {
        if (!isSmsAlertsEnabled()) return
        if (!hasSmsPermission()) return
        try {
            val phone = "5554" // emulator default
            SmsManager.getDefault().sendTextMessage(phone, null, "Low inventory: $text", null, null)
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to send SMS: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

}
