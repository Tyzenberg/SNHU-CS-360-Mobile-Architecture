package com.example.inventoryapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity

class AddItemActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_item)

        val editName = findViewById<EditText>(R.id.newName)
        val editQty  = findViewById<EditText>(R.id.newQty)
        val editLoc  = findViewById<EditText>(R.id.newLocation)
        val editDesc  = findViewById<EditText>(R.id.newDescription)

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val name = editName.text.toString().trim()
            val qty  = editQty.text.toString().toIntOrNull() ?: 0
            val loc  = editLoc.text.toString().trim().ifEmpty { null }
            val desc  = editDesc.text.toString().trim().ifEmpty { null }

            if (name.isEmpty()) {
                Toast.makeText(this, "Please enter a name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            DatabaseHelper(this).addItem(name, qty, loc, description = desc)
            Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show()
            finish() // return to inventory screen
        }

        findViewById<Button>(R.id.btnCancel).setOnClickListener { finish() }
    }
}
