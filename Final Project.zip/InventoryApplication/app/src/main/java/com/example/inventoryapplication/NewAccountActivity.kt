
package com.example.inventoryapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity

class NewAccountActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_account)

        val etUser = findViewById<EditText>(R.id.etNewUsername)
        val etPass = findViewById<EditText>(R.id.etNewPassword)
        val etConf = findViewById<EditText>(R.id.etConfirmPassword)

        findViewById<Button>(R.id.btnCreate).setOnClickListener {
            val u = etUser.text.toString().trim()
            val p = etPass.text.toString()
            val c = etConf.text.toString()
            if (u.isEmpty() || p.isEmpty()) { Toast.makeText(this,"Enter username and password",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (p != c) { Toast.makeText(this,"Passwords do not match",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (DatabaseHelper(this).createUser(u,p)) {
                Toast.makeText(this,"Account created",Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this,"Username already exists",Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.btnCancel).setOnClickListener { finish() }
    }
}
