package com.example.inventoryapplication

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(ctx: Context)
    : SQLiteOpenHelper(ctx, "inventory_app.db", null, /* bump */ 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS users(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS items(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                qty INTEGER NOT NULL,
                location TEXT,
                description TEXT
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldV: Int, newV: Int) {
        // Non-destructive migrations
        if (oldV < 2) {
            db.execSQL("ALTER TABLE items ADD COLUMN description TEXT")
        }
    }

    fun createUser(username: String, password: String): Boolean {
        return try {
            val cv = ContentValues().apply {
                put("username", username.trim())
                put("password", password)
            }
            writableDatabase.insertOrThrow("users", null, cv) > 0
        } catch (e: Exception) { false }
    }

    fun validateUser(username: String, password: String): Boolean {
        readableDatabase.query(
            "users", arrayOf("id"),
            "username=? AND password=?", arrayOf(username.trim(), password),
            null, null, null
        ).use { return it.moveToFirst() }
    }

    fun addItem(name: String, qty: Int, location: String?, description: String?): Long {
        val cv = ContentValues().apply {
            put("name", name.trim())
            put("qty", qty)
            put("location", location)
            put("description", description)
        }
        return writableDatabase.insert("items", null, cv)
    }

    fun updateItem(id: Long, name: String, qty: Int, location: String?, description: String?): Int {
        val cv = ContentValues().apply {
            put("name", name.trim())
            put("qty", qty)
            put("location", location)
            put("description", description)
        }
        return writableDatabase.update("items", cv, "id=?", arrayOf(id.toString()))
    }

    fun deleteItem(id: Long): Int =
        writableDatabase.delete("items", "id=?", arrayOf(id.toString()))

    fun allItems(): Cursor =
        readableDatabase.query(
            "items",
            arrayOf("id","name","qty","location","description"),
            null, null, null, null,
            "id DESC"
        )
}
