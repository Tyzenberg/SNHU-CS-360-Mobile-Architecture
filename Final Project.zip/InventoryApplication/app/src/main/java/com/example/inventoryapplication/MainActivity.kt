
package com.example.inventoryapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.widget.TextView
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val username = findViewById<EditText>(R.id.loginUsername)
        val password = findViewById<EditText>(R.id.loginPassword)

        findViewById<Button>(R.id.btnSignIn).setOnClickListener {
            val ok = DatabaseHelper(this).validateUser(username.text.toString(), password.text.toString())
            if (ok) startActivity(Intent(this, InventoryActivity::class.java))
            else Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnCreateAccount).setOnClickListener {
            startActivity(Intent(this, NewAccountActivity::class.java))
        }
        findViewById<Button>(R.id.btnForgot).setOnClickListener {
            Toast.makeText(this, "Demo app: no password recovery", Toast.LENGTH_SHORT).show()
        }

        findViewById<TextView>(R.id.skipLogin).setOnClickListener {
            val intent = Intent(this, InventoryActivity::class.java)
            startActivity(intent)
            finish() // optional, prevents going back to login
        }

    }
}
